// server.js - Serveur backend avec web scraping pour l'analyse de produits TPT
import express from 'express';
import cors from 'cors';
import axios from 'axios';
import { load } from 'cheerio';

const app = express();
const PORT = 3001;

// Vérification des dépendances au démarrage
try {
  // eslint-disable-next-line no-unused-expressions
  axios;
  // eslint-disable-next-line no-unused-expressions
  load;
  console.log('Les modules requis (axios, cheerio) sont chargés avec succès.');
} catch (e) {
  console.error('Erreur: Les modules "axios" ou "cheerio" ne sont pas installés. Veuillez exécuter "npm install express cors axios cheerio" dans votre terminal.');
  process.exit(1);
}

app.use(express.json());
app.use(cors());

/**
 * Fonction pour extraire les données d'un produit TPT à partir de son URL.
 * @param {string} url - L'URL complète du produit TPT.
 * @returns {object|null} - Un objet contenant les données du produit ou null en cas d'échec.
 */
const scrapeProductData = async (url) => {
  try {
    console.log(`[scrapeProductData] Début de l'extraction pour l'URL : ${url}`); // LOG SUPPLEMENTAIRE
    const config = {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
        'Referer': 'https://www.google.com/'
      },
      timeout: 10000,
    };
    
    console.log('[scrapeProductData] --- Début de la requête Axios ---'); // LOG SUPPLEMENTAIRE
    const response = await axios.get(url, config);
    console.log('[scrapeProductData] --- Fin de la requête Axios ---'); // LOG SUPPLEMENTAIRE

    const { data, status } = response;
    
    console.log(`[scrapeProductData] Statut de la réponse Axios: ${status}`);
    
    if (status !== 200) {
      console.error(`[scrapeProductData] Erreur: La requête a échoué avec le statut ${status}. Le site a peut-être bloqué votre serveur.`);
      return null;
    }

    if (!data || data.length < 100) {
      console.error('[scrapeProductData] Erreur: La réponse ne contient pas de données HTML valides ou suffisantes.');
      console.log('[scrapeProductData] Contenu de la réponse (partiel):', data ? data.substring(0, 100) : 'Aucune donnée.');
      return null;
    }
    
    console.log('[scrapeProductData] Contenu de la réponse HTML (partiel):', data.substring(0, 200));

    const $ = load(data);

    // Fonction d'aide pour extraire le texte d'un élément
    const getText = (selector) => {
      const element = $(selector);
      if (element.length) {
        console.log(`[scrapeProductData] Sélecteur trouvé: '${selector}'`);
        return element.text().trim();
      }
      console.log(`[scrapeProductData] Sélecteur manquant: '${selector}'`);
      return null;
    };

    const getAttr = (selector, attr) => {
      const element = $(selector);
      if (element.length) {
        console.log(`[scrapeProductData] Sélecteur d'attribut trouvé: '${selector}' pour l'attribut '${attr}'`);
        return element.attr(attr);
      }
      console.log(`[scrapeProductData] Sélecteur d'attribut manquant: '${selector}' pour l'attribut '${attr}'`);
      return null;
    };

    // --- Extraction des données ---
    const title = getText('h1[class*="productTitle"]');
    const description = getText('div[class*="product-description-content"]');
    const priceText = getText('div[class*="price_"] span[class*="priceText"]');
    const price = priceText ? parseFloat(priceText.replace('$', '').replace(',', '.')) : null;
    const ratingsCountText = getText('span[class*="ratingsCount"]');
    const ratingsCount = ratingsCountText ? parseInt(ratingsCountText.replace(/[()]/g, ''), 10) : null;
    const averageRatingText = getAttr('div[class*="averageRating_"] span', 'aria-label');
    const averageRating = averageRatingText ? parseFloat(averageRatingText.split(' ')[0]) : null;
    const seller = getText('a[class*="sellerName"]');
    const sellerUrl = getAttr('a[class*="sellerName"]', 'href');
    const pageCountText = getText('div[class*="pageCount_"]');
    const pageCount = pageCountText ? parseInt(pageCountText.split(' ')[0], 10) : null;
    
    const estimatedSales = ratingsCount ? ratingsCount * 10 : null;
    const estimatedProfit = (estimatedSales && price) ? estimatedSales * price * 0.5 : null;

    console.log('[scrapeProductData] Données extraites pour le débogage:');
    console.log({
      title,
      description,
      price,
      ratingsCount,
      averageRating,
      seller,
      sellerUrl,
      pageCount,
      estimatedSales,
      estimatedProfit
    });

    if (!title || !price || !ratingsCount) {
      console.error('[scrapeProductData] Échec de l\'extraction. Les données essentielles sont manquantes. Les sélecteurs CSS ne correspondent probablement plus.');
      return null;
    }

    return {
      title,
      description,
      price,
      ratings: ratingsCount,
      averageRating,
      seller,
      sellerUrl,
      pageCount,
      estimatedSales,
      estimatedProfit,
      url,
    };
  } catch (error) {
    console.error(`[scrapeProductData] Échec de la requête HTTP pour l'URL ${url}:`, error.message);
    if (error.response) {
      console.error(`[scrapeProductData] Détails de l'erreur de réponse : Statut ${error.response.status}`);
    } else if (error.code === 'ECONNABORTED') {
      console.error('[scrapeProductData] Erreur: La requête a expiré après 10 secondes. Le site est peut-être trop lent ou bloque la connexion.');
    }
    return null;
  }
};

app.get('/api/analyze/product', async (req, res) => {
  console.log("\n--- L'API a été appelée ! ---"); // LOG SUPPLEMENTAIRE
  const productUrl = req.query.url;

  if (!productUrl) {
    return res.status(400).json({ message: 'URL du produit manquante' });
  }

  console.log(`\nAnalyse de l'URL : ${productUrl}`);
  
  const productData = await scrapeProductData(productUrl);
  
  if (productData) {
    res.json(productData);
  } else {
    res.status(500).json({ message: 'Échec de l\'analyse du produit. Vérifiez les logs du serveur pour plus de détails.' });
  }
});

app.listen(PORT, () => {
  console.log(`Serveur en écoute sur le port ${PORT}`);
});
