// backend/server.js

require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const axios = require('axios'); // Importez axios pour les requêtes HTTP
const cheerio = require('cheerio'); // Importez cheerio pour l'analyse du HTML

const app = express();

// Middleware
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:5173',
    credentials: true
}));
app.use(express.json());

// Connexion à la base de données PostgreSQL
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT,
});

// Test de la connexion
pool.connect()
    .then(() => {
        console.log('Connecté à la base de données PostgreSQL.');
    })
    .catch(err => {
        console.error('Erreur de connexion à la base de données PostgreSQL :', err.message);
    });

// Route d'enregistrement (Register)
app.post('/api/auth/register', async (req, res) => {
    // ... (code existant pour l'enregistrement)
    const { name, email, password } = req.body;
    try {
        const result = await pool.query(
            'INSERT INTO users (name, email, password) VALUES ($1, $2, $3) RETURNING *',
            [name, email, password]
        );
        const newUser = result.rows[0];
        res.status(201).json({ user: newUser, message: 'Utilisateur enregistré avec succès.' });
    } catch (error) {
        console.error('Erreur d\'enregistrement de l\'utilisateur:', error);
        res.status(500).json({ message: 'L\'enregistrement a échoué. Veuillez réessayer.' });
    }
});

// Route de connexion (Login)
app.post('/api/auth/login', async (req, res) => {
    // ... (code existant pour la connexion)
    const { email, password } = req.body;
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        const user = result.rows[0];

        if (!user || user.password !== password) {
            return res.status(401).json({ message: 'Email ou mot de passe incorrect.' });
        }

        res.status(200).json({ user, message: 'Connexion réussie.' });
    } catch (error) {
        console.error('Erreur de connexion:', error);
        res.status(500).json({ message: 'La connexion a échoué. Veuillez réessayer.' });
    }
});

// NOUVELLE ROUTE : API de scraping
app.get('/api/scrape', async (req, res) => {
    const { keyword } = req.query; // Récupérer le mot-clé de la requête
    if (!keyword) {
        return res.status(400).json({ message: 'Le mot-clé est requis.' });
    }

    const url = `https://www.teacherspayteachers.com/browse/Search:${encodeURIComponent(keyword)}`;

    try {
        const { data } = await axios.get(url);
        const $ = cheerio.load(data);
        const products = [];

        // Exemple de scraping : trouver les titres des produits
        // Cette sélecteur CSS est un exemple, il peut varier.
        $('h3.product-title').each((i, element) => {
            const title = $(element).text().trim();
            products.push({ title });
        });

        res.status(200).json({ products });
    } catch (error) {
        console.error('Erreur de scraping:', error);
        res.status(500).json({ message: 'Le scraping a échoué. Veuillez réessayer.' });
    }
});


const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
