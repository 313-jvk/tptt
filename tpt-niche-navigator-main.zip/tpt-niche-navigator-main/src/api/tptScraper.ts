// src/api/tptScraper.ts
export const analyzeTPTProduct = async (url: string) => {
  try {
    // La requête est maintenant envoyée au bon endpoint du serveur : '/api/analyze-product'
    const response = await fetch('/api/analyze-product', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    
    // Vérifier si la réponse est OK (status 200-299) avant de la parser
    if (!response.ok) {
        throw new Error(`Erreur HTTP: ${response.status} ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("API Error:", error);
    throw error;
  }
};
