// server-test.js
import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 3001;

app.use(cors());

// Cette route simple répond avec un JSON et affiche un message dans le terminal
app.get('/api/test', (req, res) => {
  console.log("J'ai reçu une requête sur /api/test !");
  res.json({ message: 'Le serveur fonctionne correctement !' });
});

app.listen(PORT, () => {
  console.log(`Serveur de test en écoute sur le port ${PORT}`);
});
